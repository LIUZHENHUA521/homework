package lala;

public class BestPlayer extends Player{
    public BestPlayer(){

    }
    public BestPlayer(String name,int age){
         super(name,age);
    }

    @Override
    public void eat() {
        System.out.println("吃鲍鱼");
    }

    @Override
    public void playGame() {
        System.out.println("打篮球比赛");
    }
}
