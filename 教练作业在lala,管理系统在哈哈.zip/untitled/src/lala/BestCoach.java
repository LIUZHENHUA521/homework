package lala;

public class BestCoach extends Coach{
    public BestCoach(){

    }
    public BestCoach(String name,int age){
        super(name,age);
    }

    @Override
    public void teach() {
        System.out.println("教打篮球");
    }

    @Override
    public void eat() {
        System.out.println("吃鲍鱼");
    }
}
