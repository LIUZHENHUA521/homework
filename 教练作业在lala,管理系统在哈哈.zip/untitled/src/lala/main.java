package lala;

public class main {
    public static void main(String[] args) {
        BestPlayer BP = new BestPlayer("张三",18);
        BP.playGame();
        BestCoach BC = new BestCoach("李四",30);
        BC.teach();
        PingPlayer PP = new PingPlayer("乌拉",14);
        PP.speak();
    }
}
