package lala;

public class PingCoach extends Coach implements sperkEn{
   public PingCoach(){

    }
    public PingCoach(String name,int age){
       super(name,age);
    }

    @Override
    public void eat() {
        System.out.println("吃土");
    }

    @Override
    public void teach() {
        System.out.println("教打乒乓球");
    }
    public void speak(){
        System.out.println("说英语");
    }
}
