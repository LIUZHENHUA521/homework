package lala;

public interface sperkEn {
    public void speak();
}
