package lala;

public class PingPlayer extends Player implements sperkEn{
   public PingPlayer(){

    }
    public PingPlayer(String name,int age){
       super(name, age);
    }

    @Override
    public void eat() {
        System.out.println("吃土");
    }

    @Override
    public void playGame() {
        System.out.println("打乒乓球比赛");
    }
    public void speak(){
        System.out.println("说英语");
    }
}
