package haha;

public class dog {
}
