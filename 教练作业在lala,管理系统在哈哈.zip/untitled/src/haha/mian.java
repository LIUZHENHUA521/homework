package haha;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;



public class mian {
    public static void main(String[] args) {
        ArrayList<student> students = new ArrayList<>();
        ArrayList<Game>  games = new ArrayList<>();
        //获取输入结果
        while (true){
            System.out.println("------欢迎来到学生管理系统-------");
            System.out.println("1 添加学生");
            System.out.println("2 删除学生");
            System.out.println("3 修改学生");
            System.out.println("4 查找学生资料");
            System.out.println("5 添加比赛项目");
            System.out.println("6 删除比赛项目");
            System.out.println("7 修改比赛项目");
            System.out.println("8 查找比赛项目");
            System.out.println("9 为学生添加比赛");
            System.out.println("10 退出");
            System.out.println("请输入你的选择：");
            //Scaner
            String num = getInput();
            switch (num){
                case "1":
                    addStudent(students);
                    break;
                case "2":
                    removeStudent(students);
                    break;
                case "3":
                    changeStuentMessage(students);
                    break;
                case  "4":
                    selectStuent(students,games);
                    break;
                case "5":
                    //System.out.println("添加比赛项目");
                    addGame(games);
                    break;
                case "6":
                    //System.out.println("删除比赛项目");
                    removeGame(games);
                    break;
                case "7":
                    //System.out.println("修改比赛项目");
                    changeGameMessage(games);
                    break;
                case "8":
                   // System.out.println("查看比赛项目");
                    selectGame(games);
                    break;
                case "9":
                    addGameForStudent(students,games);break;
                case "10":
                    System.out.println("感谢您的使用");
                    System.exit(0);
            }
        }
    }
    public static void addGameForStudent(ArrayList<student> students,ArrayList<Game> games){
        System.out.println("请输入要添加项目的学生的信息");
        Map<String,Integer> result = selectStudentType2(students);
        selectGameType1(games);
        int i = result.get("index");//students的index
        String id = String.valueOf(result.get("id"));
        if(i==-1){
            System.out.println("未找到该学生");
        }else {
            addItem(i,students,games);
        }
    }

    public static void addItem(int i ,ArrayList<student> students,ArrayList<Game> games){
        System.out.println("请输入要为改学生添加的项目号，输入over结束");
        String gameId = getInput();
        if(gameId.equals("over")){
            System.out.println("添加结束");
            return;
        }else{
            if(!judgeIsExistGames(games,gameId)){
                System.out.println("未找到该项目号对于项目，请重新输入");
                addItem(i,students,games);

            }else{
                while (true) {
                    student a = students.get(i);
                    ArrayList<String> gameIds = a.getGameIds();
                    gameIds.add(gameId);
                    a.setGameIds(gameIds);
                    System.out.println("添加成功,请继续输入");
                    gameId = getInput();
                    if(gameId.equals("over")){
                        System.out.println("添加结束");
                        break;
                    }else if(!judgeIsExistGames(games,gameId)){
                        System.out.println("未找到该项目号对于项目，添加结束");
                        break;
                    }
                    addItem(i,students,games);
                }

            }
        }
    }
    public static void addGame(ArrayList<Game> games){
        System.out.println("请输入比赛号：");
        String id = getInput();
        if(judgeIsExistGames(games,id)){
            System.out.println("该比赛号为重复学号,请重新输入");
            addGame(games);//如果还是重复的学号，这里就调用自身即可
        }else{
            System.out.println("请输入比赛名");
            String name = getInput();
            System.out.println("请输入比赛时间");
            String age = getInput();
            System.out.println("请输入地址");
            String address = getInput();
            Game newStu = new Game(id,name,age,address);
            games.add(newStu);
            System.out.println("添加成功");
        }
    }
    public static boolean judgeIsExistGames(ArrayList<Game> games,String id){
        boolean state = false;
        for(int i = 0;i<games.size();i++){
            if(games.get(i).getGameId().equals(id)){
                state = true;
                break;
            }
        }
        return state;
    }
    public static void selectGameType1(ArrayList<Game> games){
        if(games.size()==0){
            System.out.println("暂时还没有比赛");
        }else{
            System.out.println("项目号"+"      "+"项目名"+"       "+"比赛时间"+"          "+"地址");
            for(int i=0;i<games.size();i++){
                Game A = games.get(i);
                showGameMessage(games,i);
            }
        }
    }
    public static Map<String, Integer> selectGameType2(ArrayList<Game> games){
        Map<String,Integer> object = new HashMap<>();
        System.out.println("请输入项目号：");
        String id = getInput();
        int j =-1;
        for(int i=0;i<games.size();i++){
            Game a = games.get(i);
            if(a.getGameId().equals(id)){
                System.out.println("项目号"+"      "+"项目名"+"       "+"比赛时间"+"          "+"地址");
                showGameMessage(games,i);
                j = i;
                break;//这里注意每个人学号有且只要一个，不会出现，所以一旦查询到就可以跳出循环
            }
        }
        if(j==-1){
            System.out.println("未查找到该项目号的比赛");
        }
        object.put("index",j);
        object.put("id",Integer.parseInt(id));
        return object;
    }
    public  static  void selectGameType3(ArrayList<Game> games){
        System.out.println("请输入项目名：");
        String name = getInput();
        for(int i = 0;i<games.size();i++){
            Game a = games.get(i);
            if(a.getName().equals(name)){
                System.out.println("项目号"+"      "+"项目名"+"       "+"比赛时间"+"          "+"地址");
                showGameMessage(games,i);

            }else{
                System.out.println("未查询到相关信息");
            }
        }
    }
    public static  void  selectGame(ArrayList<Game> games){
        ArrayList<String> titles = new ArrayList<>();
        titles.add("如需要查询全部项目");
        titles.add("如需要按照项目号查找");
        titles.add("如需要按照项目名查早");
        for(int i=0;i<titles.size();i++){
            System.out.println(titles.get(i)+"请输入"+"  "+(i+1));
        }
        String navNum = getInput();
        switch (navNum){
            case "1":selectGameType1(games);break;
            case "2":selectGameType2(games);break;
            case "3":selectGameType3(games);break;
            default:
                System.out.println("输入错误，请重新输入");
                selectGame(games);//输入错误就再次调用自己，重新输入内容
        }
    }
    public static  void removeGame(ArrayList<Game> games){
        if(games.size()==0){
            System.out.println("暂时还没有比赛");
        }else{
            System.out.println("请输入要删除项目的信息");
            int i = selectGameType2(games).get("index");
            if(i==-1){//说明没有找到该学号的学生
                System.out.println("删除失败");
            }else{
                System.out.println("请问是该项目吗？如果确认要删除的话请输入1,放弃修改请输入0");
                String orderNum = getInput();//确认删除
                if(orderNum.equals("1")){
                    games.remove(i);
                    System.out.println("删除成功");
                }
                else if(orderNum.equals("0")){
                    System.out.println("放弃删除");
                }
                else {
                    System.out.println("输入错误，请重新操作");
                }
            }
        }

    }
    public static void changeGameMessage(ArrayList<Game> games){
        System.out.println("请输入要修改的项目的信息");
        Map<String,Integer> result = selectGameType2(games);
        int i = result.get("index");//students的index
        String id = String.valueOf(result.get("id"));//获取输入的学号
        if(i==-1){
            System.out.println("修改失败");
        }else{
            System.out.println("请输入要修改项目名");
            String name = getInput();
            System.out.println("请输入要修改时间");
            String age = getInput();
            System.out.println("请输入要修改地址");
            String address = getInput();
            Game newStudent = new Game(id,name,age,address);
            games.set(i,newStudent);
            System.out.println("修改成功");
        }
    }
    public static void showGameMessage(ArrayList<Game> games,int i){
        System.out.println(games.get(i).getGameId()+"          "+games.get(i).getName()+"              "+games.get(i).getTime()+"               "+games.get(i).getAddress());
    }
    public static void addStudent(ArrayList<student> students){
        System.out.println("请输入学号：");
        String id = getInput();
         if(judgeIsExist(students,id)){
             System.out.println("该学号为重复学号,请重新输入");
             addStudent(students);//如果还是重复的学号，这里就调用自身即可
         }else{
             System.out.println("请输入姓名");
             String name = getInput();
             System.out.println("请输入年龄");
             String age = getInput();
             System.out.println("请输入地址");
             String address = getInput();
             student newStu = new student(id,name,age,address);
             students.add(newStu);
             System.out.println("添加成功");
         }
    }
    public static String getInput(){
        Scanner sc = new Scanner(System.in);
        String content = sc.nextLine();
        return content;
    }//获取输入的内容
    public static  boolean judgeIsExist(ArrayList<student> students,String id){
        boolean state = false;
        for(int i = 0;i<students.size();i++){
            if(students.get(i).getId().equals(id)){
                state = true;
                break;
            }
        }
        return state;
    }//遍历查看添加学生学号是否重复
    public static void selectStudentType1(ArrayList<student> students){
        if(students.size()==0){
            System.out.println("暂时还没有学生");
        }else{
            System.out.println("学号"+"      "+"姓名"+"       "+"年龄"+"          "+"住址"+"              "+"项目id列表");
            for(int i=0;i<students.size();i++){
                student A = students.get(i);
                showMessege(students,i);
            }
        }
    }//展示全部添加的学生

    public static Map<String, Integer> selectStudentType2(ArrayList<student> students){
        Map<String,Integer> object = new HashMap<>();
        System.out.println("请输入学号：");
        String id = getInput();
        int j =-1;
        for(int i=0;i<students.size();i++){
            student a = students.get(i);
            if(a.getId().equals(id)){
                System.out.println("学号"+"      "+"姓名"+"       "+"年龄"+"          "+"住址"+"                 "+"项目id列表");
                showMessege(students,i);
                j = i;
                break;//这里注意每个人学号有且只要一个，不会出现，所以一旦查询到就可以跳出循环
            }
        }
        if(j==-1){
            System.out.println("未查找到该学号的学生");
        }
        object.put("index",j);
        object.put("id",Integer.parseInt(id));
        return object;
    }//这个函数在修改和删除中要复用，且需要两个关键的返回值，一个是students的index,一个是输入的学号
    public  static  void selectStudentType3(ArrayList<student> students){
        System.out.println("请输入姓名：");
        String name = getInput();
        for(int i = 0;i<students.size();i++){
            student a = students.get(i);
            if(a.getName().equals(name)){
                System.out.println("学号"+"      "+"姓名"+"       "+"年龄"+"          "+"住址"+"                   "+"项目id列表");
                showMessege(students,i);

            }else{
                System.out.println("未查询到相关信息");
            }
        }
    }
    public static  void  showMessege(ArrayList<student> students,int i){
        System.out.println(students.get(i).getId()+"      "+students.get(i).getName()+"       "+students.get(i).getAge()+"          "+students.get(i).getAddress()+"            "+students.get(i).getGameIds());
    }//更加方便打印学生内容
    public static  void  selectStuent(ArrayList<student> students,ArrayList<Game> games){
        ArrayList<String> titles = new ArrayList<>();
        titles.add("如需要查询全部学生");
        titles.add("如需要按照学号查找学生");
        titles.add("如需要按照姓名查找学生");
        for(int i=0;i<titles.size();i++){
            System.out.println(titles.get(i)+"请输入"+"  "+(i+1));
        }

        String navNum = getInput();
        selectGameType1(games);
        switch (navNum){
            case "1":selectStudentType1(students);break;
            case "2":selectStudentType2(students);break;
            case "3":selectStudentType3(students);break;
            default:
                System.out.println("输入错误，请重新输入");
                selectStuent(students,games);//输入错误就再次调用自己，重新输入内容
        }
    }
    public static  void removeStudent(ArrayList<student> students){
        if(students.size()==0){
            System.out.println("还没有学生");
        }else {
            System.out.println("请输入要删除学生的信息");
            int i = selectStudentType2(students).get("index");
            if(i==-1){//说明没有找到该学号的学生
                System.out.println("删除失败");
            }else{
                System.out.println("请问是该学生吗？如果确认要删除的话请输入1,放弃修改请输入0");
                String orderNum = getInput();//确认删除
                if(orderNum.equals("1")){
                    students.remove(i);
                    System.out.println("删除成功");
                }
                else if(orderNum.equals("0")){
                    System.out.println("放弃删除");
                }
                else {
                    System.out.println("输入错误，请重新操作");
                }
            }
        }

    }
    public static void changeStuentMessage(ArrayList<student> students){
        System.out.println("请输入要修改的学生的信息");
        Map<String,Integer> result = selectStudentType2(students);
        int i = result.get("index");//students的index
        String id = String.valueOf(result.get("id"));//获取输入的学号
        if(i==-1){
            System.out.println("修改失败");
        }else{
            System.out.println("请输入要修改姓名");
            String name = getInput();
            System.out.println("请输入要修改年龄");
            String age = getInput();
            System.out.println("请输入要修改地址");
            String address = getInput();
            student newStudent = new student(id,name,age,address);
            students.set(i,newStudent);
            System.out.println("修改成功");
        }
    }

}
