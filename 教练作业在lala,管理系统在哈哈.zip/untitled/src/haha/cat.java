package haha;

public class cat {
}
