package haha;

public class Game {
    private String gameId;
    private String name;
    private String time;
    private String address;

    public Game(String gameId, String name, String time, String address) {
        this.gameId = gameId;
        this.name = name;
        this.time = time;
        this.address = address;
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
