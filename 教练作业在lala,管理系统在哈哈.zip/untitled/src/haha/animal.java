package haha;

public class animal {
    public String age;
}
